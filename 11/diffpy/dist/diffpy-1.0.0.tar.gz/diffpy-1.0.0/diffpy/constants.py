import math

e = math.e
pi = math.pi
sin = math.sin
cos = math.cos
tan = lambda x: sin(x) / cos(x)
cot = lambda x: cos(x) / sin(x)
log = math.log